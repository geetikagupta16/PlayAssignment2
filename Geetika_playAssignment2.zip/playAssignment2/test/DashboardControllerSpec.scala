import controllers.DashboardController
import models.{Employee, EmployeeDetailsApi}
import org.junit.runner.RunWith
import org.specs2.mock.Mockito
import org.specs2.mutable._
import org.specs2.runner._
import play.api.test.Helpers._
import play.api.test._
import org.mockito.Mockito._
import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global

import scala.concurrent.Future

/**
  * Created by knoldus on 5/3/16.
  */

@RunWith(classOf[JUnitRunner])
class DashboardControllerSpec extends Specification with Mockito {

  val service = mock[EmployeeDetailsApi]
  val econtroller = new DashboardController(service)

  "DashboardController" should {

    "send 404 on a bad request" in new WithApplication {
      route(FakeRequest(GET, "/boum")) must beSome.which(status(_) == NOT_FOUND)
    }

    "employee details Test" in new WithApplication {
      when(service.getDetails()).thenReturn(Future(List(Employee("abc", "Mohan nagar", "10-12-89", "12-10-2010", "trainee"), Employee("pqr", "dabri", "10-12-89", "12-10-2010", "trainee"))))
      val res = call(econtroller.employeeDetails(), FakeRequest(GET, "/"))
      status(res) must equalTo(OK)
    }

    "render the dashboard page" in new WithApplication {
      val home = route(FakeRequest(GET, "/")).get
      status(home) must equalTo(OK)
      contentType(home) must beSome.which(_ == "text/html")
      contentAsString(home) must contain("Play Assignment")
    }

    "render the addEmployee page" in new WithApplication {
      val home = route(FakeRequest(POST, "/addForm")).get
      status(home) must equalTo(OK)
      contentType(home) must beSome.which(_ == "text/html")
    }

    "render the updateEmployee page" in new WithApplication {
      val home = route(FakeRequest(GET, "/update?name=abc")).get
      status(home) must equalTo(OK)
      contentType(home) must beSome.which(_ == "text/html")
    }

    "Submit Form:Add Employee" in new WithApplication {
      val addSubmit = route(FakeRequest(POST, "/add").withFormUrlEncodedBody("name" -> "alice", "address" -> "Janak Puri", "dob" -> "1993-12-10", "joiningDate" -> "1993-12-10", "designation" -> "trainee")).get
      status(addSubmit) must equalTo(SEE_OTHER)
    }

    "Submit Form:Update Employee" in new WithApplication {
      val updateSubmit = route(FakeRequest(POST, "/update").withFormUrlEncodedBody("name" -> "jacob", "address" -> "Janak Puri", "dob" -> "1993-12-10", "joiningDate" -> "1993-12-10", "designation" -> "trainee")).get
      status(updateSubmit) must equalTo(SEE_OTHER)
    }

    "Submit Form:Delete Employee" in new WithApplication {
      val deleteSubmit = route(FakeRequest(POST, "/delete").withFormUrlEncodedBody("name" -> "jacob", "address" -> "Janak Puri", "dob" -> "1993-12-10", "joiningDate" -> "1993-12-10", "designation" -> "trainee")).get
      status(deleteSubmit) must equalTo(SEE_OTHER)
    }

    "Filter Employee" in new WithApplication {
      val res = route(FakeRequest(POST, "/filter").withFormUrlEncodedBody("name" -> "abc")).get
      status(res) must equalTo(OK)
    }

  }
}