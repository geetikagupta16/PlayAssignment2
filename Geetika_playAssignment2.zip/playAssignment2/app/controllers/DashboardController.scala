package controllers

import com.google.inject.Inject
import models.{Employee, EmployeeDetailsApi}
import play.api.data.Form
import play.api.data.Forms._
import play.api.i18n.Messages.Implicits._
import play.api.Play.current
import play.api.mvc.{Action, Controller}
import scala.concurrent.ExecutionContext.Implicits.global

import scala.concurrent.Future

/**
  * Created by knoldus on 4/3/16.
  */
class DashboardController @Inject()(emp: EmployeeDetailsApi) extends Controller {

  val filterForm = Form(
    single(
      "name" -> nonEmptyText
    )
  )
  val updateForm = Form(
    mapping(
      "name" -> nonEmptyText,
      "address" -> nonEmptyText,
      "dob" -> nonEmptyText,
      "joiningDate" -> nonEmptyText,
      "designation" -> nonEmptyText
    )(Employee.apply)(Employee.unapply)
  )
  val addForm = Form(
    mapping(
      "name" -> nonEmptyText,
      "address" -> nonEmptyText,
      "dob" -> nonEmptyText,
      "joiningDate" -> nonEmptyText,
      "designation" -> nonEmptyText
    )(Employee.apply)(Employee.unapply)
  )
  var employee: Employee = Employee("", "", "", "", "")

  def filterEmployee() = Action.async { implicit request =>
    filterForm.bindFromRequest.fold(
      formWithErrors => {
        // Redirect(routes.DashboardController.employeeDetails)
        val futureEmp: Future[List[Employee]] = emp.getDetails()
        val res = futureEmp.map(x => Ok(views.html.dashboard(x, filterForm, x.length)))
        res
      },
      userData => {
        val futureEmp = emp.getDetails()
        val res = futureEmp.map(a => a.filter(x => x.name == userData))
        res.map(x => Ok(views.html.dashboard(x, filterForm, x.length)))

      }

    )
  }


  def employeeDetails() = Action.async({ implicit request =>

    val futureEmp: Future[List[Employee]] = emp.getDetails()
    //val len=futureEmp.map(x=>x.length)

    val res = futureEmp.map(x => Ok(views.html.dashboard(x, filterForm, x.length)))
    res
  })

  def getAddEmployeeForm() = Action { implicit request =>
    Ok(views.html.addEmployee(addForm))
  }

  def addEmployee = Action { implicit request =>
    addForm.bindFromRequest.fold(
      formWithErrors => {
        Redirect(routes.DashboardController.getAddEmployeeForm).flashing("error" -> "Addition Failed")
      },
      userData => {
        emp.addEmployee(userData)
        Redirect(routes.DashboardController.employeeDetails).flashing("success" -> "Employee Added successfully")
      }

    )
  }

  def getUpdateEmployeeForm(name: String) = Action.async({ implicit request =>
    val futureEmp = emp.getDetails()
    val res: Future[List[Employee]] = futureEmp.map(a => a.filter(x => x.name == name))
    res.map(x => employee = x.head)
    res.map(x => Ok(views.html.updateEmployee(updateForm.fill(x.head))))

  })

  def updateEmployee() = Action { implicit request =>

    updateForm.bindFromRequest.fold(
      formWithError => {
        Redirect(routes.DashboardController.employeeDetails).flashing("error" -> "Updation Failed")
      },
      data => {
        emp.updateEmployee(employee, data)
        Redirect(routes.DashboardController.employeeDetails).flashing("success" -> "Updation Succeeded !!!!")
      })

  }

  def deleteEmployee() = Action { implicit request =>

    if (updateForm.hasErrors) {
      Redirect(routes.DashboardController.employeeDetails).flashing("error" -> "Deletion Failed")
    }
    else {
      emp.deleteEmployee(employee)
      Redirect(routes.DashboardController.employeeDetails).flashing("success" -> "Deletion Succeeded !!!!")
    }
  }

}
