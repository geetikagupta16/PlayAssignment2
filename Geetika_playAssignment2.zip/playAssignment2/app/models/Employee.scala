package models

import com.google.inject.ImplementedBy

import scala.collection.mutable.ListBuffer
import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global


/**
  * Created by knoldus on 4/3/16.
  */
case class Employee (name:String,address:String,dob:String,joiningDate:String,designation:String)

@ImplementedBy(classOf[EmployeeService])
trait EmployeeDetailsApi{

  def getDetails():Future[List[Employee]]
  def addEmployee(emp:Employee)
  def updateEmployee(oldEmployee: Employee,newEmployee:Employee)
  def deleteEmployee(employee: Employee)

}

class EmployeeService extends EmployeeDetailsApi{

  val employees=ListBuffer(Employee("abc","Mohan nagar","1988-09-12","1988-09-12","trainee"),Employee("pqr","dabri","1988-09-12","1988-09-12","trainee"),Employee("def","rajapuri","1988-09-12","1988-09-12","trainee"),Employee("xyz","Janak Puri","1988-09-12","1988-09-12","trainee"))

  def getDetails():Future[List[Employee]]={

   Future(employees.toList)
  }

  def addEmployee(emp:Employee)={

    employees+=emp
  }
  def updateEmployee(oldEmployee: Employee,newEmployee:Employee)={
    employees+=newEmployee
    employees-=oldEmployee
  }

  def deleteEmployee(employee: Employee)={
    employees-=employee
  }
}